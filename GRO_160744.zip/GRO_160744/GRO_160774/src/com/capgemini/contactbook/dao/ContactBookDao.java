package com.capgemini.contactbook.dao;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookException;

public interface ContactBookDao {
	//public String addEnquiry(EnquiryBean enqry) throws ContactBookException;
public EnquiryBean getEquiryDetails(int EnquiryID) throws ContactBookException;
public String addDetailsEnquiry(EnquiryBean enqry) throws ContactBookException;
public String addContactBookDetails(EnquiryBean patientbean);
public EnquiryBean viewContactDetails(String donorId);

}






