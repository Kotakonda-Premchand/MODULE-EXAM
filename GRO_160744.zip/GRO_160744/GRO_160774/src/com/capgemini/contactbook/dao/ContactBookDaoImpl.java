package com.capgemini.contactbook.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.util.DBConnection;

public class ContactBookDaoImpl implements ContactBookDao {
	Logger logger=Logger.getRootLogger();
	public ContactBookDaoImpl()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	@SuppressWarnings({ "resource", "null" })
	public String addDetailsEnquiry(EnquiryBean enqry) throws ContactBookException {
		{
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		String donorId=null;
		
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

EnquiryBean contact = null;
preparedStatement.setInt(3, contact.getEnqryId());
			
			
			preparedStatement.setString(1, contact.getfName());
			preparedStatement.setString(1, contact.getlName());
			preparedStatement.setString(1, contact.getContactNo());
			preparedStatement.setString(1, contact.getpLocation());

			preparedStatement.setString(4, contact.getpDomain());
				
	queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.ENQUIRYID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				donorId=resultSet.getString(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new ContactBookException("Inserting donor details failed ");

			}
			else
			{
				logger.info("Donor details added successfully:");
				return donorId;
			}

		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new ContactBookException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new ContactBookException("Error in closing db connection");
			}
		}}}
		
		
		public EnquiryBean getEquiryDetails(int EnquiryID) throws ContactBookException {		
		Connection connection=DBConnection.getInstance().getConnection();
		
		
		PreparedStatement preparedStatement=null;
		ResultSet resultset = null;
		EnquiryBean bean=null;
		String person_id=null;
		
		try
		{
			preparedStatement=connection.prepareStatement(QueryMapper.VIEW_ENQUIRY_DETAILS_QUERY);
			preparedStatement.setString(1,person_id);
			resultset=preparedStatement.executeQuery();
			
			if(resultset.next())
			{
				bean = new EnquiryBean();
				bean.setfName(resultset.getString(1));
				bean.setlName(resultset.getString(2));
				bean.setContactNo(resultset.getString(3));
				bean.setpLocation(resultset.getString(4));
				bean.setpDomain(resultset.getString(5));
				
			}
			
			if( bean != null)
			{
				logger.info("Record Found Successfully");
				return bean;
			}
			else
			{
				logger.info("Record Not Found Successfully");
				return null;
			}
			
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
			throw new ContactBookException(e.getMessage());
		}
		finally
		{
			try 
			{
				resultset.close();
				preparedStatement.close();
				connection.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new ContactBookException("Error in closing db connection");

			}
		}
		
	}
		@Override
		public String addContactBookDetails(EnquiryBean patientbean) {
			// TODO Auto-generated method stub
			return null;
		}
		@Override
		public EnquiryBean viewContactDetails(String donorId) {
			// TODO Auto-generated method stub
			return null;
		}


	}