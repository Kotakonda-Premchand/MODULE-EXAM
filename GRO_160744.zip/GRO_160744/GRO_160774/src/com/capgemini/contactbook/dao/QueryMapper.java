package com.capgemini.contactbook.dao;

public class QueryMapper {
	public static final String VIEW_ENQUIRY_DETAILS_QUERY="SELECT enqryId,firstName,lastName, contactNo, domain, city FROM enquiry WHERE  enquiry_id=?";
		public static final String INSERT_QUERY="INSERT INTO enquiry VALUES(enquiries.NEXTVAL,?,?,?,?, (select SYSDATE from DUAL))";
		public static final String ENQUIRYID_QUERY_SEQUENCE="SELECT enquiries.CURRVAL FROM DUAL";
		
}
/*
CREATE TABLE enquiry(enqryId Number Primary Key , firstName Varchar2(20), 
lastName varchar2(20), contactNo Number(10), domain Varchar2(20), city Varchar2(20));
*/