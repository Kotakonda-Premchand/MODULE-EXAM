package com.capgemini.contactbook.exception;

public class ContactBookException extends Throwable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ContactBookException(String message) 
	{
		
		super(message);
	}}
