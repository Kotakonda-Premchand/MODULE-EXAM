
package com.capgemini.contactbook.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.ContactBookException;

public  class ContactBookServiceImpl implements ContactBookService {
	
	ContactBookDao contactbookDao;
	
	
	public String addContactBookDetails(EnquiryBean patientbean) throws ContactBookException {
		
		contactbookDao= new ContactBookDaoImpl();
		String patient_Id_sequence;
		patient_Id_sequence= contactbookDao.addContactBookDetails(patientbean);
		return patient_Id_sequence;
	}

	
		public void validateContact(EnquiryBean bean) throws Throwable
		{
			List<String> validationErrors = new ArrayList<String>();

			//Validating name
			if(!(isValidfName(bean.getfName()))) {
				validationErrors.add("\n Patient Name Should Be In Alphabets and minimum 3 characters long ! \n");
			}
			//Validating last name
			if(!(isValidlName(bean.getlName()))){
				validationErrors.add("\nlast name  Should Be In Alphabets \n");
			}
			//validating contact number
			if(!(isValidContactNumber(bean.getContactNo()))){
                validationErrors.add("\n contact number should be of 10 digits \n");
            }
			//Validating Preferred domain
			if(!(isValidDomain(bean.getpDomain()))){
				validationErrors.add("\n domain should not be empty\n");
			}
			//Validating Preferred location
			if(!(isValidLocation(bean.getpLocation()))){
				validationErrors.add("\n location should not be empty \n");
			}
			
			
			
			
		
			if(!validationErrors.isEmpty())
				throw new ContactBookException(validationErrors +"");
		}

		public boolean isValidfName(String name){
			Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
			Matcher nameMatcher=namePattern.matcher(name);
			return nameMatcher.matches();
		}
		public boolean isValidlName(String name){
			Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
			Matcher nameMatcher=namePattern.matcher(name);
			return nameMatcher.matches();
		}
		
		
		
		
		public boolean isValidContactNumber(String contactNumber){
			Pattern phonePattern=Pattern.compile("^[1-9]{1}[0-9]{9}$");
			Matcher phoneMatcher=phonePattern.matcher(contactNumber);
			return phoneMatcher.matches();
			
		}
		public boolean isValidDomain(String domain){
			Pattern phonePattern=Pattern.compile("^[A-Za-z]{4,}$");
			Matcher phoneMatcher=phonePattern.matcher(domain);
			return phoneMatcher.matches();
			
		}public boolean isValidLocation(String location){
			Pattern phonePattern=Pattern.compile("^[A-Za-z]{4,}$");
			Matcher phoneMatcher=phonePattern.matcher(location);
			return phoneMatcher.matches();
			
		}
		
		
		public boolean validateContactId(String contact_id) {
			
			Pattern idPattern = Pattern.compile("[0-9]{1,4}");
			Matcher idMatcher = idPattern.matcher(contact_id);
			
			if(idMatcher.matches())
				return true;
			else
				return false;		
		}





	
		public EnquiryBean viewContactDetails(String donorId) throws ContactBookException {
			contactbookDao=new ContactBookDaoImpl();
			EnquiryBean bean=null;
			bean=contactbookDao.viewContactDetails(donorId);
			return bean;
		}


		@Override
		public EnquiryBean viewDonorDetails(String donorId) throws ContactBookException {
			// TODO Auto-generated method stub
			return null;
		}


		@Override
		public String addEnquiryDetails(EnquiryBean patientbean) {
			// TODO Auto-generated method stub
			return null;
		}



}


		
