package com.capgemini.contactbook.service;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookException;

public interface ContactBookService {
	public String addContactBookDetails(EnquiryBean patientbean) throws ContactBookException;
	public EnquiryBean viewDonorDetails(String donorId) throws ContactBookException;
	public String addEnquiryDetails(EnquiryBean patientbean);

	
}

