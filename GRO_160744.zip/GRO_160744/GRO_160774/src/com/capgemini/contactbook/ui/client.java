
package com.capgemini.contactbook.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;

@SuppressWarnings("unused")
public class client  {

	static Scanner sc = new Scanner(System.in);
	static ContactBookService patientService = null;
	static ContactBookServiceImpl patientServiceImpl = null;
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) throws Exception, ContactBookException {
		PropertyConfigurator.configure("resources//log4j.properties");
		EnquiryBean contact = null;

		String contact_id = null;
		int option = 0;

		
		while (true) {

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("   Choose an operation  ");
			System.out.println("_______________________________\n");

			System.out.println("1.Enter Enquiry Details ");
			System.out.println("2.View Enquiry Details on Id");
			System.out.println("3.Exit");
			
			System.out.println("________________________________");
			System.out.println("Please enter a choice :");
			// accept option

			try {
				option = sc.nextInt();

				switch (option) {

				case 1:

					while (contact  == null) {
						contact   = enquirybean ();
						 System.out.println(contact);
					}

					try {
						patientService = new ContactBookServiceImpl();
						contact_id = patientService.addEnquiryDetails(contact);

						System.out.println("Patient details  has been successfully registered ");
						System.out.println("Patient  ID Is: " + contact_id);

					} finally {
						contact_id = null;
						patientService = null;
						contact = null;
					}

					break;


				case 2:

					System.out.print("Exit Patient Application");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-4]");
				}// end of switch
			}

			catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
		}

		}// end of while
	}

	private static EnquiryBean enquirybean() {
		// TODO Auto-generated method stub
		return null;
	}

	private static EnquiryBean populatePatientbean() throws Throwable {

		
		EnquiryBean contact = new EnquiryBean();

		System.out.println("\n Patient Details");

		System.out.println("Enter first name: ");
		contact.setfName(sc.next());
		System.out.println("Enter last name: ");
		contact.setlName(sc.next());
		
		
		System.out.println("Enter contact no: ");
		contact.setContactNo(sc.next());
		
		System.out.println("Enter Domain: ");
		contact.setpDomain(sc.next());
		System.out.println("Enter preferred location: ");
		contact.setpDomain(sc.next());
		
	
		
        ContactBookServiceImpl contactServiceImpl = new ContactBookServiceImpl();

		try {
			contactServiceImpl.validateContact(contact);
			
			System.out.println("after validate patient");
			return contact ;
		} catch (ContactBookException patientsException) {
			logger.error("exception occured", patientsException);
			System.err.println("Invalid data:");
			System.err.println(patientsException.getMessage() + " \n Try again..");
			System.exit(0);

		}
		return null;

	}}
